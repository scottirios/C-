﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.classes
{
    public class ViagemInternacional : Viagem
    {
        public string Pais {  get; set; }
        public bool PrecisaVisto { get; set; }

        public ViagemInternacional(string destino,decimal preco, string pais, bool precisaVisto) : base (destino,preco)
        {
            Pais = pais;
            PrecisaVisto = precisaVisto;
        }

        public override void ExibirDetalhes()
        {
            string visto = PrecisaVisto ? "Sim" : "Não";
            Console.WriteLine($"Destino Internacional: {Destino}, País: {Pais}, Preço: {Preco}, Precisa de Visto? {visto}");
        }
    }
}
