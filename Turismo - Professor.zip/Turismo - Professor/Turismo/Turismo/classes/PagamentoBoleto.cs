﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.classes
{
    public class PagamentoBoleto : Pagamento
    {
        public string NumeroBoleto { get; set; }

        public PagamentoBoleto(decimal valor, string numeroBoleto) : base (valor)
        {
            NumeroBoleto = numeroBoleto;
        }

        public override void ExibirDetalhes()
        {
            Console.WriteLine($"Pagamento com Boleto - Valor: {Valor:C}, Número do Boleto: {NumeroBoleto}");
        }
    }
}
