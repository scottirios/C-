﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.classes
{
    public class PagamentoCartao : Pagamento
    {
        public string NumeroCartao { get; set; }

        public PagamentoCartao(decimal valor, string numeroCartao) : base (valor)
        {
            NumeroCartao = numeroCartao;
        }

        public override void ExibirDetalhes()
        {
            Console.WriteLine($"Pagamento com cartão - Valor: {Valor:C}, Número do Cartão: {NumeroCartao}");
        }
    }
}
