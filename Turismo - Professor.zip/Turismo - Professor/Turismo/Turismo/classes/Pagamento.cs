﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Turismo.interfaces;

namespace Turismo.classes
{
    public abstract class Pagamento : IDetalhavel
    {
        public decimal Valor { get; set; }

        public Pagamento (decimal valor)
        {
            Valor = valor;
        }

        public abstract void ExibirDetalhes();
    }
}
