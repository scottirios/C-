﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.classes
{
    public class Agencia
    {
        private List<Viagem> viagens = new List<Viagem>();
        private List<Cliente> clientes = new List<Cliente>();
        private List<Reserva> reservas = new List<Reserva>();

        public List<Viagem> Viagens { get => viagens; }
        public List<Cliente> Clientes { get => clientes; }
        public List<Reserva> Reservas { get => reservas; }

        public void AdicionarCliente(Cliente cliente)
        {
            if (clientes.Exists(c => c.Email == cliente.Email))
            {
                throw new Exception("Cliente já existe!");
            }

            clientes.Add(cliente);
            Console.WriteLine($"Cliente {cliente.Nome} foi adicionado!");
        }

        public void AdicionarViagem(Viagem viagem)
        {
            viagens.Add(viagem);
            Console.WriteLine($"Viagem para {viagem.Destino} foi adicionada.");
        }

        public void ListarClientes()
        {
            Console.WriteLine("Clientes registrados na agência: ");
            foreach (var cliente in clientes)
            {
                cliente.ExibirDetalhes();
            }
        }

        public void ListarViagens()
        {
            Console.WriteLine("Viagens registrados na agência: ");
            foreach (var viagem in viagens)
            {
                viagem.ExibirDetalhes();
            }
        }
        public void RealizarReserva(Viagem viagem, Cliente cliente)
        {
            Reserva reserva = new Reserva(viagem, cliente);
            reservas.Add(reserva);
            Console.WriteLine($"Reserva para {cliente.Nome} na viagem {viagem.Destino} foi reservada.");
        }

        public void AtualizarReserva(Reserva reserva, Viagem Novaviagem)
        {
            reserva.Viagem = Novaviagem;
            Console.WriteLine($"Reserva para {reserva.Cliente.Nome} foi atualizada.");
        }

        public void ListarReservas()
        {
            Console.WriteLine("Reservas registrados na agência: ");
            foreach (var reserva in reservas)
            {
                reserva.ExibirDetalhes();
            }
        }

        public void ListarReservasPorCliente(Cliente cliente)
        {
            Console.WriteLine($"Reservas registradas para o cliente: {cliente.Nome}: ");
            foreach(var reserva in  reservas)
            {
                if (reserva.Cliente.Email == cliente.Email)
                {
                    reserva.ExibirDetalhes();
                }
            }
        }

        public void CancelarReserva(Reserva reserva)
        {
            reservas.Remove(reserva);
            Console.WriteLine($"Reserva para {reserva.Cliente.Nome} foi cancelada.");
        }

        public List<Viagem> FiltrarViagensPorPreco(decimal precoMaximo)
        {
            return viagens.FindAll(v => v.Preco <= precoMaximo);
        }

        public List<Viagem> FiltrarViagensPorDestino(string destino)
        {
            return viagens.FindAll(v => v.Destino.IndexOf(destino, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        public List<Viagem> FiltrarViagensPorTipo(Type tipo)
        {
            return viagens.FindAll(v => v.GetType() == tipo);
        }

    }
}
