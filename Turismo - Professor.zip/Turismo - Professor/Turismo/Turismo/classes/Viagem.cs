﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turismo.interfaces;

namespace Turismo.classes
{
    public abstract class Viagem : IDetalhavel
    {
        public string Destino { get; set; }
        public decimal Preco { get; set; }

        public Viagem(string destino, decimal preco)
        {
            Destino = destino;
            Preco = preco;

        }

        public abstract void ExibirDetalhes();

    }

}
