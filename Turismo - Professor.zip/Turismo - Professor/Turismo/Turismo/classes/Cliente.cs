﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turismo.interfaces;

namespace Turismo.classes
{
    public class Cliente : IReservavel
    {
        public string Nome { get; set; }
        public string Email { get; set; }

        public Cliente(string nome, string email)
        {
            Nome = nome;
            Email = email;
        }

        public void ExibirDetalhes()
        {
            Console.WriteLine($"Cliente: {Nome}, Email: {Email}");
        }
    }
}
