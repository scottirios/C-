﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.classes
{
    public class ViagemNacional : Viagem
    {
        public string Estado {  get; set; }

        public ViagemNacional (string destino, decimal preco, string estado) : base(destino,preco)
        {
            Estado = estado;
        }

        public override void ExibirDetalhes()
        {
            Console.WriteLine($"Destino Nacional: {Destino}, Estado: {Estado}, Preço: {Preco}");
        }
    }
}
