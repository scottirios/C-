﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.classes
{
    public class Reserva
    {
        public Viagem Viagem { get; set; }
        public Cliente Cliente { get; set; }
        public List<Pagamento> Pagamentos { get; set; }

        public Reserva(Viagem viagem, Cliente cliente)
        {
            Viagem = viagem;
            Cliente = cliente;
            Pagamentos = new List<Pagamento>();
        }

        public void AdicionarPagamento(Pagamento pagamento)
        {
            Pagamentos.Add(pagamento);
        }

        public void ExibirDetalhes()
        {
            Console.WriteLine($"Reserva para {Cliente.Nome}");
            Viagem.ExibirDetalhes();

            foreach (var pagamento in Pagamentos)
            {
                pagamento.ExibirDetalhes();
            }
        }
    }
}
