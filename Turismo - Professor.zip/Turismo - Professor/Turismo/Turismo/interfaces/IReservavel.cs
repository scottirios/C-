﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turismo.interfaces
{
    internal interface IReservavel
    {
        void ExibirDetalhes();
    }
}
