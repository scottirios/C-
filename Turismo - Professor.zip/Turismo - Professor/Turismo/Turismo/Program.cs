﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Turismo.classes;

namespace Turismo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Agencia agencia = new Agencia();

            while (true) 
            {
                Console.WriteLine("Selecione a opção desejada: ");
                Console.WriteLine("1. Adicional Cliente");
                Console.WriteLine("2. Adicionar Viagem ");
                Console.WriteLine("3. Adicionar Reserva");
                Console.WriteLine("4. Atualizar Reserva");
                Console.WriteLine("5. Listar Clientes");
                Console.WriteLine("6. Listar Viagens");
                Console.WriteLine("7. Listar Reservas");
                Console.WriteLine("8. Listar Reservas por cliente");
                Console.WriteLine("9. Cancelar Reserva");
                Console.WriteLine("10. Filtrar viagens por Preço");
                Console.WriteLine("11. Filtrar viagens por Destino");
                Console.WriteLine("12. Filtrar viagens por Tipo");
                Console.WriteLine("13. Sair");

                string opcao = Console.ReadLine();

                if (opcao == "13")
                {
                    break;
                }

                try
                {
                    switch (opcao)
                    {
                        case "1":
                            Console.WriteLine("Digite o nome do cliente:");
                    }
                }

            }
        }
    }
}
