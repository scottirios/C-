﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacaoFuncional
{
    public class Loja
    {
        private List<Produto> produtosDisponiveis;

        public Loja(List<Produto> produtos)
        {
            produtosDisponiveis = new List<Produto>(produtos);
        }

        public List<Produto> BuscarProdutos(string nome)
        {
            // LINQ
            return produtosDisponiveis.Where(p => p.Nome.Contains(nome, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public Pedido ProcessarPedido(Carrinho carrinho, Func<decimal, decimal> calcularDesconto)
        {
            decimal totalSemDesconto = carrinho.CalcularTotal();
            decimal totalComDeconto = calcularDesconto(totalSemDesconto);

            var pedido = new Pedido(
                id: new Random().Next(1, 1000),
                cliente: carrinho.Cliente,
                produtos: carrinho.Produtos,
                data: DateTime.Now
            );

            Console.WriteLine($"Pedido {pedido.Id} para {pedido.Cliente.Nome}");
            Console.WriteLine($"Total sem desconto {totalSemDesconto:C}");
            Console.WriteLine($"Total com desconto {totalComDeconto:C}");

            return pedido;
        }
    }
}
