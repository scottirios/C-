﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacaoFuncional
{
    public class Cliente //Imutavel
    {
        public int Id { get; }
        public string Nome { get; }

        public Cliente(int id, string nome)
        {
            Id = id;
            Nome = nome;
        }
    }
}
