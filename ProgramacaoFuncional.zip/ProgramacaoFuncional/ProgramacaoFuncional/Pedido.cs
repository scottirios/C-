﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacaoFuncional
{
    public class Pedido
    {
        public int Id { get; }
        public Cliente Cliente { get; }
        public List<Produto> Produtos { get; }
        public DateTime Data {  get; }

        public Pedido(int id, Cliente cliente, List<Produto> produtos, DateTime data)
        {
            Id = id;
            Cliente = cliente;
            Produtos = produtos;
            Data = data;
            Produtos = new List<Produto>(produtos);
        }

        public decimal CalcularValorTotal() => Produtos.Sum(p => p.Preco);
    }
}
