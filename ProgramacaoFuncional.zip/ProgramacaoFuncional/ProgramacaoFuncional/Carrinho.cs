﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ProgramacaoFuncional
{
    public class Carrinho
    {
        public Cliente Cliente { get; }
        public List<Produto> Produtos { get; }

        public Carrinho(Cliente cliente, List<Produto> produtos)
        {
            Cliente = cliente;
            Produtos = new List<Produto>(produtos);

        }

        public Carrinho AdicionarProduto(Produto produto)
        {
            var novaLista = new List <Produto>(Produtos) { produto };
            return new Carrinho(Cliente, novaLista);
        }

        public Carrinho RemoverProduto(Produto produto)
        {

            var novaLista = new List<Produto>(Produtos);
            novaLista.Remove(produto);
            return new Carrinho(Cliente,novaLista);
        }

        // Função pura para calcular o total do carrinho
        public decimal CalcularTotal() => Produtos.Sum(p => p.Preco);




    }
}
