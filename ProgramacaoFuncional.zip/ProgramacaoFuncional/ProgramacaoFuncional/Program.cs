﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using ProgramacaoFuncional;

class Program
{
    static void Main(string[] args)
    {
        var produtos = new List<Produto>
        {
            new Produto(1, "Camisa", 50m),
            new Produto(2, "Jaqueta", 80m),
            new Produto(3, "Calça", 110m),
            new Produto(4, "Tênis", 140m),
        };

        var loja = new Loja(produtos);

        var cliente = new Cliente(1, "Lucas Renan");

        var carrinho = new Carrinho(cliente, new List<Produto>());

        // LINQ
        var busca = loja.BuscarProdutos("ca");
        Console.WriteLine("Produtos encontrados:");
        foreach (var produto in busca)
        {
            Console.WriteLine($"- {produto.Nome} - {produto.Preco}");
        }

        // Carrinho era vazio, tinha apenas cliente e lista vazia
        // Imutabilidade
        carrinho = carrinho.AdicionarProduto(produtos[2]);
        carrinho = carrinho.AdicionarProduto(produtos[3]);

        Console.WriteLine($"Total carrinho: {carrinho.CalcularTotal()}");

        Func<decimal, decimal> calcularDesconto = total =>
        {
            if (total > 100)
                return total * 0.9m;
            else
                return total;
        };

        var pedido = loja.ProcessarPedido(carrinho, calcularDesconto);
    }
}