﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email
{
    public class FakeEmailService : IEmailService
    {
        public bool EmailEnviado { get; private set; } = false;
        public string UltimoDestinatario { get; private set; }
        public string UltimoAssunto { get; private set; }
        public string UltimaMensagem { get; private set; }

        public void EnviarEmail(string destinatario, string assunto, string mensagem)
        {
            EmailEnviado = true;
            UltimoDestinatario = destinatario;
            UltimoAssunto = assunto;
            UltimaMensagem = mensagem;
        }
    }

}
