﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email
{
    public class NotificacaoService
    {
        private readonly IEmailService _emailService;

        public NotificacaoService(IEmailService emailService)
        {
            _emailService = emailService;
        }

        public void EnviarNotificacao(string destinatario, string assunto, string mensagem)
        {
            _emailService.EnviarEmail(destinatario, assunto, mensagem);
            Console.WriteLine("Notificação enviada com sucesso.");
        }
    }

}
