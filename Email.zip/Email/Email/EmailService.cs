﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email
{
    public class EmailService : IEmailService
    {
        public void EnviarEmail(string destinatario, string assunto, string mensagem)
        {
            Console.WriteLine($"E-mail enviado para: {destinatario}, Assunto: {assunto}");
        }
    }
}
