using Email;

namespace EmailTests
{
    public class NotificacaoServiceTests
    {
        [Fact]
        public void Deve_Enviar_Notificacao_Com_Sucesso()
        {
            // Arrange
            var fakeEmailService = new FakeEmailService();
            var notificacaoService = new NotificacaoService(fakeEmailService);
            var destinatario = "empresa@gmail.com";
            var assunto = "Nota Fiscal e XML";
            var mensagem = "Prezado cliente, segue em anexo.";

            // Act
            notificacaoService.EnviarNotificacao(destinatario, assunto, mensagem);

            // Assert
            Assert.True(fakeEmailService.EmailEnviado);
            Assert.Equal(destinatario, fakeEmailService.UltimoDestinatario);
            Assert.Equal(assunto, fakeEmailService.UltimoAssunto);
            Assert.Equal(mensagem, fakeEmailService.UltimaMensagem);
        }
    }
}